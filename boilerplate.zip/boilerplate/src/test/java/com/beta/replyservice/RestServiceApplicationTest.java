package com.beta.replyservice;

import com.beta.replyservice.ReplyMessage;
import com.beta.exception.InvalidRequestException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RestServiceApplicationTest {

	String errorMessage = "Input parameters are invalid. Please verify and try again : ";
	
	@Test
	public void contextLoads() {
	}

	@Test
	public void testEmptyInputError() {
		Exception exception = assertThrows(InvalidRequestException.class, () -> {
			ReplyMessage result = new ReplyMessage("13", "");
	    });

	    String actualMessage = exception.getMessage();
	    assertTrue(actualMessage.contains(errorMessage));
	}
	
	@Test
	public void testInvalidParamError() {
		Exception exception = assertThrows(InvalidRequestException.class, () -> {
			ReplyMessage result = new ReplyMessage("", "");
	    });

	    String actualMessage = exception.getMessage();
	    assertTrue(actualMessage.contains(errorMessage));
	}
	
	@Test
	public void testSingleReverse() {
		ReplyMessage result = new ReplyMessage("1", "kbzw9ru");
		assertNotNull(result);
		assertEquals("ur9wzbk", result.getMessage());
	}
	
	@Test
	public void testDoubleReverse() {
		ReplyMessage result = new ReplyMessage("11", "kbzw9ru");
		assertNotNull(result);
		assertEquals("kbzw9ru", result.getMessage());
	}
	
	@Test
	public void testSingleReverseAndMD5() {
		ReplyMessage result = new ReplyMessage("12", "kbzw9ru");
		assertNotNull(result);
		assertEquals("5a8973b3b1fafaeaadf10e195c6e1dd4", result.getMessage());
	}
}
