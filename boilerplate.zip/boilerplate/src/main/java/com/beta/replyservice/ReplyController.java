package com.beta.replyservice;

import static org.slf4j.LoggerFactory.getLogger;

import org.slf4j.Logger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.PathVariable;

@RestController
public class ReplyController {

	private static final Logger log = getLogger(ReplyController.class);
	
	@GetMapping("/reply")
	public ReplyMessage replying() {

		log.info("reply api called");
		return new ReplyMessage("Message is empty");
	}

	@GetMapping("/reply/{message}")
	public ReplyMessage replying(@PathVariable String message) {

		log.info("/reply/{message} api called with param : {}", message);
		return new ReplyMessage(message);
	}

	@GetMapping("/v2/reply/{operation}-{message}")
	public ReplyMessage replying(@PathVariable String operation, @PathVariable String message) {

		log.info("/v2/reply/{operation}-{message} api called with params : {} {}", operation, message);
		return new ReplyMessage(operation, message);
	}
}