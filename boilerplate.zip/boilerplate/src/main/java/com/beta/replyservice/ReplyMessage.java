package com.beta.replyservice;

import static com.beta.constant.Constants.ENCRYPT;
import static com.beta.constant.Constants.REVSERSE;
import static org.slf4j.LoggerFactory.getLogger;

import org.slf4j.Logger;
import org.springframework.util.StringUtils;

import com.beta.exception.InvalidRequestException;
import com.beta.util.Md5Util;

public class ReplyMessage {

	private static final Logger log = getLogger(ReplyMessage.class);

	private String message;
	private String operation;

	public ReplyMessage(String message) {
		this.message = message;
	}

	public ReplyMessage(String operation, String message) {

		if (StringUtils.isEmpty(message) || StringUtils.isEmpty(operation)) {
			formatException(message, operation);
		}
		String result = message;
		StringBuilder sbr = new StringBuilder(result);
		for (char s : operation.toCharArray()) {
			if (REVSERSE.equalsIgnoreCase("" + s)) {
				sbr.reverse();
			} else if (ENCRYPT.equalsIgnoreCase("" + s)) {
				sbr = new StringBuilder(Md5Util.getMD5(sbr.toString()));
			} else {
				formatException(message, operation);
			}
		}
		this.message = sbr.toString();
		this.operation = operation;
	}

	public String getMessage() {
		return message;
	}

	private void formatException(String operation, String message) {
		throw new InvalidRequestException(
				"Input parameters are invalid. Please verify and try again : " + message + operation);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ReplyMessage [message=").append(message).append("]");
		return builder.toString();
	}

}