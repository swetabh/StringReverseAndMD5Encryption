package com.beta.exceptions;

import static org.slf4j.LoggerFactory.getLogger;
import static org.springframework.core.Ordered.HIGHEST_PRECEDENCE;

import javax.print.attribute.standard.Severity;

import org.slf4j.Logger;
import com.beta.exception.ApiError;
import com.beta.exception.InvalidRequestException;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

/**
 * Exception handler for handling different types exceptions and LOG the
 * exceptions.
 *
 */
@Order(HIGHEST_PRECEDENCE)
@ControllerAdvice
public class RestExceptionHandler {

	private static final Logger log = getLogger(RestExceptionHandler.class);

	/**
	 * Handle InvalidRequestException
	 * 
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(InvalidRequestException.class)
	public ResponseEntity<ApiError> invalidRequestExceptionHandler(final InvalidRequestException ex,
			final WebRequest request) {

		log.error(ex.getMessage(), ex);
		final ApiError apiError = populateErrorMessage(ex, "101", Severity.ERROR, HttpStatus.BAD_REQUEST);
		return new ResponseEntity<>(apiError, HttpStatus.BAD_REQUEST);
	}

	protected ApiError populateErrorMessage(final Exception ex, final String errorCode, final Severity errorSeverity,
			final HttpStatus status) {

		final ApiError apiError = new ApiError(errorCode);
		apiError.setErrorSeverity(errorSeverity.getName());
		apiError.setErrorMessage(ex.getMessage());
		apiError.setErrorCode(status.name());
		return apiError;
	}
}