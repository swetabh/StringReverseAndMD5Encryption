package com.beta.exception;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiError {

	private String errorCode;

	private String errorMessage;

	private String errorSeverity;

	private ApiError() {
	}

	public ApiError(String errorCode) {
		this();
		this.errorCode = errorCode;
	}

	public ApiError(String errorCode, Throwable ex) {
		this();
		this.errorCode = errorCode;
		this.errorMessage = "Unexpected error";
	}

	public ApiError(String errorCode, String errorMessage) {
		this();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public ApiError(String errorCode, String errorMessage, String errorSeverity) {
		this();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.errorSeverity = errorSeverity;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorSeverity() {
		return errorSeverity;
	}

	public void setErrorSeverity(String errorSeverity) {
		this.errorSeverity = errorSeverity;
	}

}