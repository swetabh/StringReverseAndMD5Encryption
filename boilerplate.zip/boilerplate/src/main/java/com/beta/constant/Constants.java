package com.beta.constant;

public class Constants {

	private Constants() {
	}

	public static final String REVSERSE = "1";
	public static final String ENCRYPT = "2";

}